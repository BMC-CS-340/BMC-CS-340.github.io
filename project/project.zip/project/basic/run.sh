#!/bin/sh
java MyMain $1 $2 $3
